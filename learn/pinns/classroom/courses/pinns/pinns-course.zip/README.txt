PINNs postgraduate course: a 120-minute teaching plan.
Open courses/pinns/guide.html for the full English script, Chinese equivalents, diagrams, equations, teaching timetable, notation and linked primary sources. You may print this teacher guide.
The class time includes narration, student activities, discussion and a ten-minute break. It is not 120 minutes of uninterrupted recorded speech.

Reproduce the independent synthetic experiments with Python 3.12:
  python -m venv .venv-pinns
  .venv-pinns/Scripts/python.exe -m pip install torch numpy --index-url https://download.pytorch.org/whl/cpu
  .venv-pinns/Scripts/python.exe demos/pinns_train.py
Exact tested package versions are recorded in courses/pinns/requirements-pinns-lock.txt. The runs use float64, four CPU threads and seed 7. The full trace includes actual validation errors, the true coefficient and noisy inverse observations. No paper figure or claimed paper benchmark is reproduced.

The interactive professor requires the running Virtual Professor application. Open http://127.0.0.1:4317/?course=pinns there. English George audio is cached by that local app; voice models and audio caches are not embedded in this small material archive. Lesson JSON files preserve editable bilingual narration, LaTeX, schematics, spoken cues and activity pauses. The HTML guide and numeric traces can be read independently.
